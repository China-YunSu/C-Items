#include <stdio.h>
#include <malloc.h>

#include "./include/GraphConstruct.h"
#include "./include/Hash.h"
#include "./include/boolean.h"
#include "./include/ModifyGraph.h"

static boolean InsertNode(GraphNode *head,GraphNode *insertNode);
static boolean RemoveNode(GraphNode *head, int tab);
static boolean IsHadNode(GraphNode *head, int tab);

boolean ModifyNodeInformation(Graph *graph, int tabA, int tabB, int value) {
	GraphNode *check = NULL;

	if (tabA < 0 || tabB < 0) {
		return FALSE;
	} 

	for (check = graph->node[tabA]->next; check != NULL; check = check->next) {
		if (check->data.tab == tabB) {
			check->data.edgeValue = value;
			return TRUE;
		}
	}

	return FALSE;
}	

boolean DelOneEdge(Graph *graph, int tabA, int tabB) {
	if (tabA < 0 || tabB < 0) {
		return FALSE;
	}

	return RemoveNode(graph->node[tabA], tabB) && RemoveNode(graph->node[tabB], tabA) ?
	 --graph->edgeCount : 0;
}

boolean IsEmpty(Graph *graph) {
	return graph->nodeCount <= 0;
}

boolean IsFull(Graph *graph) {
	return graph->nodeCount >= graph->capacity;
}

boolean DelOneNode(Graph *graph, int tab) {
	int index = 0;
	if (tab < 0 || IsEmpty(graph)) {
		return FALSE;
	}

	for (; index < graph->nodeCount; ++index) {
		RemoveNode(graph->node[index], tab);
	}

	for (index = tab; graph->node[index]->next;) {
		graph->edgeCount -= RemoveNode(graph->node[index], graph->node[index]->next->data.tab);
	}

	for (index = tab; index + 1 < graph->nodeCount; index++) {
		graph->node[index] = graph->node[index + 1];
	}
	--graph->nodeCount;
}

boolean AddOneEdge(Graph *graph, int tabA, int tabB, int value) {
	int flag = 0;
	if (tabA < 0 || tabB < 0) {
		return FALSE;
	}
	
	flag += InsertNode(graph->node[tabA],CreatOneNode((NodeData){value,tabB,{0}}));
	flag += InsertNode(graph->node[tabB],CreatOneNode((NodeData){value,tabA,{0}}));
	return flag == 2 ? ++graph->edgeCount : FALSE;
}

boolean AddOneNode(Graph *graph, GraphNode addNode, GraphNode node[], int count) {
	int i = 0;
	if (IsFull(graph)) {
		return FALSE;
	}

	graph->node[graph->nodeCount] = CreatOneNode(addNode.data);

	for (i = 0; i < count; ++i) {
		graph->edgeCount += InsertNode(graph->node[graph->nodeCount],CreatOneNode(node[i].data));
		InsertNode(graph->node[node[i].data.tab],CreatOneNode((NodeData){addNode.data.edgeValue,addNode.data.tab,{0}}));			
	}
	++graph->nodeCount;
}

static boolean IsHadNode(GraphNode *head, int tab) {
	GraphNode *check = head->next;

	while(check != NULL && check->data.tab != tab) {
		check = check->next;
	}	

	return check != NULL;
}

static boolean InsertNode(GraphNode *head,GraphNode *insertNode) {	
	if (IsHadNode(head,insertNode->data.tab)) {
		return FALSE;
	}
	
	GraphNode *tmp = head->next;
	head->next = insertNode;
	insertNode->next = tmp;
	
	return TRUE;
}

static boolean RemoveNode(GraphNode *head, int tab) {
	GraphNode *pre = head;
	GraphNode *cur = head->next;

	while (cur != NULL && cur->data.tab != tab) {
		pre = cur;
		cur = cur ->next;
	}

	if (cur == NULL)  {
		return FALSE;
	}
	pre->next = cur->next;
	free(cur);
	return TRUE;
}

// int main(int argc, char const *argv[]) {

// 	Graph *graph = NULL;
// 	HashTable *nameIndex = NULL;

// 	char cityA[8] = {0};
// 	char cityB[8] = {0};

// 	InitHashTable(&nameIndex, 1024);	
// 	InitGraph(&graph, 1024);

// 	nameIndex = SetGraph(graph);

// 	printGraph(graph);

// 	printf("���������ӳ���1��");
// 	scanf("%s", cityA);
// 	printf("���������ӳ���2��");
// 	scanf("%s", cityB);
// 	printf(" %d ",graph->nodeCount);
// 	printf("%d\n",graph->edgeCount);
// 	AddOneEdge(graph, HashGet(nameIndex,cityA), HashGet(nameIndex,cityB), 90);
// 	printf("finshed");
// 	//DelOneNode(graph, HashGet(nameIndex,cityA));
// 	//DelOneEdge(graph, HashGet(nameIndex,cityA), HashGet(nameIndex,cityB));
// 	printf(" %d ",graph->nodeCount);
// 	printf("%d\n",graph->edgeCount);
	
// 	printGraph(graph);

// 	return 0;
// }