#ifndef _TYPE_H_
#define _TYPE_H_ 

char *String(unsigned int digit, char *str);
char *ToString(int digit);

#endif