#ifndef _USERTYPE_H_
#define _USERTYPE_H_ 

#include "boolean.h"
#include "GraphConstruct.h"

typedef  NodeData USER_TYPE;

boolean equal(USER_TYPE dataA, USER_TYPE dataB);

#endif