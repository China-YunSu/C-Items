#ifndef _BOOLEAN_
#define _BOOLEAN_

typedef unsigned char boolean;

#define TRUE		1
#define FALSE		0 

#endif