#ifndef _HASHCONFIGURE_H_
#define _HASHCONFIGURE_H_ 


typedef int HashItem;

#endif